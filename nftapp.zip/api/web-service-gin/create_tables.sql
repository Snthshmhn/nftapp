-- Creation of account table

CREATE TABLE IF NOT EXISTS Account (
  nric TEXT NOT NULL,
  walletaddress TEXT NOT NULL,
  PRIMARY KEY (nric)
);
