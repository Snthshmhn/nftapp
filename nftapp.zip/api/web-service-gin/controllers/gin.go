package controllers

import (
	"net/http"

	"example.com/web-service-gin/database"
	"github.com/gin-gonic/gin"
)

func CreateAccount(c *gin.Context) {
	var account *database.Account
	err := c.ShouldBind(&account)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"error": err,
		})
		return
	}
	res := database.DB.Create(account)
	if res.RowsAffected == 0 {
		c.JSON(http.StatusBadRequest, gin.H{
			"error": "error creating a account",
		})
		return
	}
	c.JSON(http.StatusOK, gin.H{
		"account": account,
	})
	return
}
