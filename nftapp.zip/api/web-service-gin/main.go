package main

import (
	"fmt"

	"example.com/web-service-gin/controllers"
	"example.com/web-service-gin/database"
	"github.com/gin-gonic/gin"
)

func main() {
	fmt.Println("Starting application ...")
	database.DatabaseConnection()

	r := gin.Default()

	r.POST("/accounts", controllers.CreateAccount)
	r.Run(":5000")
}
