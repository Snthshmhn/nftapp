import React, { Component } from 'react';

class App extends Component {
    constructor(props) {
        super(props);
        web3Provider: null;
        contracts: {};
        this.state = {
            posts: []
        }
        this.callNFTService= this.callNFTService.bind(this);
        this.initWeb3 = this.initWeb3.bind(this);
        
    }

    callNFTService(){
        alert('Calling NFT service');
        ///to code here

    }

    initWeb3() {
      if (window.ethereum) {  // Modern dapp browsers
        App.web3Provider = window.ethereum;
        try {
          window.ethereum.enable();  // Request account access
        } catch (error) {  // User denied account access...
          console.error("User denied account access")
        }
      } else if (window.web3) {  // Legacy dapp browsers
        App.web3Provider = window.web3.currentProvider;
      } else {  // If no injected web3 instance is detected, fall back to Ganache
        App.web3Provider = new Web3.providers.HttpProvider('http://localhost:7545');
      }
      web3 = new Web3(App.web3Provider);
      return App.initContract();
    }

    componentDidMount() {
        const url = "https://jsonplaceholder.typicode.com/posts";
        fetch(url)
            .then(response => response.json())
            .then(json => this.setState({ posts: json }))
    }

    render() {
        const { posts } = this.state;
        return (
            <div className="container">
                <div class="jumbotron">
                    <h1 class="display-4">Blog posts</h1>
                </div>  
                <div></div>
                <div>
                    National Registration Identity Card (NRIC)&ensp; &ensp; &ensp; &ensp;: &ensp;&ensp;<input className="e-input" name="nric" type="text" placeholder="Enter NRIC" />
                </div>
                <br />
                <div>
                    Wallet Address&ensp; &ensp; &ensp; &ensp; &ensp; &ensp; &ensp; &ensp; &ensp; &ensp; &ensp; &ensp; &ensp; &ensp; &ensp; &ensp; &ensp; &ensp; &ensp;: &ensp; &ensp;<input className="e-input" name="wallet" type="text" placeholder="Wallet Address" />
                </div>
                <button onClick={this.callNFTService}>Generate NFT image</button>              
            </div>
        );
    }
}
export default App;
